USE shoppingretail;
-- SHIPPER REQUIRMENTS

-- 1.	Show orders needed to be shipped
DROP PROCEDURE IF EXISTS ShowShipOrder;
DELIMITER //
 CREATE PROCEDURE ShowShipOrder(your_shipper_id INT(10))
	BEGIN
		SELECT * FROM orders G WHERE G.shipper_id = your_shipper_id AND G.status LIKE 'preparing';
	END//
 DELIMITER ;
CALL ShowShipOrder(1);

-- 2.	Show the total price of order
DROP PROCEDURE IF EXISTS ShowTotalPrice;
DELIMITER //
 CREATE PROCEDURE ShowTotalPrice(your_order_id INT(10))
	BEGIN
		SELECT SUM((F.quantity * A.output_price)) + G.ship_price AS Total_price FROM order_details F INNER JOIN products A ON F.product_id = A.id INNER JOIN orders G ON F.order_id = G.id WHERE your_order_id = order_id; 
	END//
 DELIMITER ;
CALL ShowTotalPrice(1);