USE shoppingretail;
-- SUPPlIER REQUIRMENTS

-- 1. See the information of input orders
DROP PROCEDURE IF EXISTS InputOrderInfo;
DELIMITER //
  CREATE PROCEDURE InputOrderInfo()
    BEGIN 
      SELECT * FROM input_orders;
    END //
  DELIMITER ;
CALL InputOrderInfo();

-- 2. See the input_orders made in a month
DROP PROCEDURE IF EXISTS SeeInputOrderInMonth;
DELIMITER //
  CREATE PROCEDURE SeeInputOrderInMonth(IN search_month INT(2))
    BEGIN 
      SELECT * FROM input_orders WHERE MONTH(DOM) =search_month;
    END //
  DELIMITER ;
CALL SeeInputOrderInMonth(4);

-- 3.	Know a product is supplied in which input orders
DROP PROCEDURE IF EXISTS SeeInputOrderOfProduct;
DELIMITER //
  CREATE PROCEDURE SeeInputOrderOfProduct(IN product_name VARCHAR(45))
    BEGIN 
      SELECT A.id FROM input_orders A INNER JOIN products B ON A.product_id = B.id WHERE B.name = product_name;
    END //
  DELIMITER ;
CALL SeeInputOrderOfProduct('Sweater');
