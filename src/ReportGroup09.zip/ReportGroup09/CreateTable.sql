DROP SCHEMA IF EXISTS `shoppingretail`;
CREATE SCHEMA `shoppingretail` ;

/*customer*/
CREATE TABLE `shoppingretail`.`customers` (
  `id` INT(10) NOT NULL AUTO_INCREMENT,
  `first_name` VARCHAR(10) NOT NULL,
  `address` TINYTEXT NOT NULL,
  `email` VARCHAR(45) NOT NULL,
  `tel` VARCHAR(14) NOT NULL,
  `last_name` VARCHAR(10) NOT NULL,
  `city` VARCHAR(20) NOT NULL,
  `country` VARCHAR(20) NOT NULL,
  PRIMARY KEY (id),
  INDEX `city` (`city` ASC),
  INDEX `first_name` (`first_name` ASC),
  INDEX `last_name` (`last_name` ASC)
  );
  
  /*shipper*/
CREATE TABLE `shoppingretail`.`shippers` (
  `id` INT(10) NOT NULL AUTO_INCREMENT,
  `first_name` VARCHAR(10) NOT NULL,
  `tel` VARCHAR(15) NOT NULL,
  `company` VARCHAR(20) NOT NULL,
  `last_name` VARCHAR(10) NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `company` (`company` ASC),
  INDEX `first_name` (`first_name` ASC),
  INDEX `last_name` (`last_name` ASC)
  );
  
  /*order*/
CREATE TABLE `shoppingretail`.`orders` (
  `id` INT(10) NOT NULL AUTO_INCREMENT,
  `ordered_date` DATETIME NOT NULL,
  `received_date` DATETIME,
  CHECK (`received_date` >= `ordered_date`),
  `ship_price` INT(10) DEFAULT 0,
  CHECK (`ship_price`>=0) ,
  `status` VARCHAR(10) NOT NULL,
  CHECK (`status` IN ('preparing','shipping','received')),
  PRIMARY KEY (`id`),
  `customer_id` INT(10) NOT NULL,
    FOREIGN KEY (`customer_id`) REFERENCES `shoppingretail`.`customers` (`id`)
    ON UPDATE CASCADE
    ON DELETE NO ACTION,
  `shipper_id` INT(10) NOT NULL,
    FOREIGN KEY (`shipper_id`)
    REFERENCES `shoppingretail`.`shippers` (`id`)
    ON UPDATE CASCADE
    ON DELETE NO ACTION,
  INDEX `customer_id` (`customer_id` ASC),
  INDEX `id` (`id` ASC),
  INDEX `shipper_id` (`shipper_id` ASC),
  INDEX `ordered_date` (`ordered_date` ASC)
  );

 /*product*/
CREATE TABLE `shoppingretail`.`products` (
  `id` INT(10) NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(45) NOT NULL,
  `status` BINARY (1) DEFAULT 0,
  `quantity` INT(10) DEFAULT 0,
  CHECK (`quantity` >= 0),
  `input_price` INT(10) DEFAULT 0,
  CHECK (`input_price` >= 0),
  `output_price` INT(10)  DEFAULT (`input_price`),
  CHECK (`output_price` >=  `input_price`),
  PRIMARY KEY (`id`));

/*producer*/
CREATE TABLE `shoppingretail`.`producers` (
  `id` INT(10) NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(45) NOT NULL,
  `address` TINYTEXT NOT NULL,
  `email` VARCHAR(45) NOT NULL,
  `tel` VARCHAR(15) NOT NULL,
  `city` VARCHAR(20) NOT NULL,
  `country` VARCHAR(20) NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `city` (`city` ASC),
  INDEX `name` (`name` ASC)
  );

/*input_orders*/
CREATE TABLE `shoppingretail`.`input_orders` (
  `id` INT(10) NOT NULL AUTO_INCREMENT,
  `quantity` INT(10) DEFAULT 0,
  CHECK (`quantity` >= 0),
  `DOM` DATETIME DEFAULT NULL,
  `DOI` DATETIME NOT NULL,
  CHECK ((`DOM` IS NOT NULL ) AND (`DOI`>=`DOM`) ) ,
  PRIMARY KEY (`id`),
  `product_id` INT(10) NOT NULL,
    FOREIGN KEY (`product_id`)
    REFERENCES `shoppingretail`.`products` (`id`)
    ON DELETE NO ACTION
    ON UPDATE CASCADE,
  `producer_id` INT(10) NOT NULL,
    FOREIGN KEY (`producer_id`)
    REFERENCES `shoppingretail`.`producers` (`id`)
    ON DELETE NO ACTION
    ON UPDATE CASCADE,
  INDEX `DOM` (`DOM` ASC),
  INDEX `DOI` (`DOI` ASC),
  INDEX `product_id` (`product_id` ASC)
  );

/*order_details*/
CREATE TABLE `shoppingretail`.`order_details` (
  `id` INT(10) NOT NULL AUTO_INCREMENT,
  `quantity` INT(10) DEFAULT 1 CHECK (`quantity` >= 1),
  PRIMARY KEY (`id`),
  `product_id` INT(10) NOT NULL,
    FOREIGN KEY (`product_id`)
    REFERENCES `shoppingretail`.`products` (`id`)
    ON DELETE NO ACTION
    ON UPDATE CASCADE,
    `order_id` INT(10) NOT NULL,
    FOREIGN KEY (`order_id`)
    REFERENCES `shoppingretail`.`producers` (`id`)
    ON DELETE NO ACTION
    ON UPDATE CASCADE,
  INDEX `order_id` (`order_id` ASC),
  INDEX `product_id` (`product_id`)
  );
  
/*book*/
CREATE TABLE `shoppingretail`.`books`(
`product_id` INT(10) NOT NULL,
FOREIGN KEY (`product_id`)
REFERENCES `shoppingretail`.`products` (`id`)
    ON DELETE NO ACTION
    ON UPDATE CASCADE,
    `genre` VARCHAR (45) NOT NULL,
    `author` VARCHAR (45) NOT NULL
);

/*clothes*/
CREATE TABLE `shoppingretail`.`clothes`(
`product_id` INT(10) NOT NULL,
FOREIGN KEY (`product_id`)
REFERENCES `shoppingretail`.`products` (`id`)
    ON DELETE NO ACTION
    ON UPDATE CASCADE,
    `size` VARCHAR (5) NOT NULL,
    `color` VARCHAR (10) NOT NULL,
    `material` VARCHAR (45)
);

