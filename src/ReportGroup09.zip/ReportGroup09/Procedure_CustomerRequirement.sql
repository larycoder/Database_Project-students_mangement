USE shoppingretail;
-- CUSTOMER REQUIREMENTS
-- 1.	Search products by name
DROP PROCEDURE IF EXISTS SearchProductsByName;
DELIMITER //
 CREATE PROCEDURE SearchProductsByName(IN search_name VARCHAR(45))
   BEGIN
    SELECT A.name, quantity, status, output_price, genre, author FROM products A INNER JOIN books B ON A.id = B.product_id WHERE name LIKE CONCAT('%',search_name,'%');
    SELECT A.name, quantity, status, output_price, size, color, material FROM products A INNER JOIN clothes C ON A.id = C.product_id WHERE name LIKE CONCAT('%',search_name,'%');
   END //
 DELIMITER ;
CALL SearchProductsByName('T-shirt');


-- 2.	Search products by price
DROP PROCEDURE IF EXISTS SearchProductsByPrice;
DELIMITER //
 CREATE PROCEDURE SearchProductsByPrice(IN min_price INT(10), max_price INT(10))
   BEGIN
    SELECT  name, quantity, status, output_price, genre, author FROM products A INNER JOIN books B ON A.id = B.product_id WHERE output_price BETWEEN min_price AND max_price ORDER BY output_price ASC;
	  SELECT  name, quantity, status, output_price, size, color, material FROM products A INNER JOIN clothes C ON A.id = C.product_id WHERE output_price BETWEEN min_price AND max_price ORDER BY output_price ASC;
   END //
 DELIMITER ;
CALL SearchProductsByPrice(200000,300000);


-- 3.	Search products by categoryDROP PROCEDURE IF EXISTS SearchProductsByCategory;
DROP PROCEDURE IF EXISTS SearchProductsByCategory;
DELIMITER //
 CREATE PROCEDURE SearchProductsByCategory(IN category_name VARCHAR(10))
   BEGIN
    IF category_name = 'books' THEN
      SELECT id,name,output_price,quantity,genre,author FROM products INNER JOIN books ON products.id = books.product_id;
    ELSE
      SELECT id,name,output_price,quantity,size,color,material FROM products INNER JOIN clothes ON products.id = clothes.product_id;
    END IF;
   END //
 DELIMITER ;
CALL SearchProductsByCategory('books');
CALL SearchProductsByCategory('clothes');

-- 4.	Search products by producer
DROP PROCEDURE IF EXISTS SearchProductsByProducer;
DELIMITER //
 CREATE PROCEDURE SearchProductsByProducer(IN producer_name VARCHAR(45))
   BEGIN
	SELECT  A.name, A.quantity, status, output_price, genre, author FROM products A INNER JOIN books B ON A.id = B.product_id INNER JOIN input_orders D ON A.id = D.product_id INNER JOIN producers E ON D.producer_id = E.id WHERE E.name LIKE CONCAT('%',producer_name,'%');
	SELECT  A.name, A.quantity, status, output_price, size, material, color FROM products A INNER JOIN clothes C ON A.id = C.product_id INNER JOIN input_orders D ON A.id = D.product_id INNER JOIN producers E ON D.producer_id = E.id WHERE E.name LIKE CONCAT('%',producer_name,'%');
   END //
 DELIMITER ;
CALL SearchProductsByProducer('Bo Sua By Boo');

-- 5.	See order list that she/he made
DROP PROCEDURE IF EXISTS ShowOrderList;
DELIMITER //
 CREATE PROCEDURE ShowOrderList(creater_id INT(10))
	BEGIN
		SELECT * FROM orders WHERE customer_id = creater_id; 
	END//
 DELIMITER ;
CALL ShowOrderList(1);

-- 6.	Show the total price of order
DROP PROCEDURE IF EXISTS ShowTotalPrice;
DELIMITER //
 CREATE PROCEDURE ShowTotalPrice(your_order_id INT(10))
	BEGIN
		SELECT SUM((F.quantity * A.output_price)) + G.ship_price AS Total_price FROM order_details F INNER JOIN products A ON F.product_id = A.id INNER JOIN orders G ON F.order_id = G.id WHERE your_order_id = order_id; 
	END//
 DELIMITER ;
CALL ShowTotalPrice(1);

-- 7.	Show information of shipper who ship the order
DROP PROCEDURE IF EXISTS ShowInfShipper;
DELIMITER //
 CREATE PROCEDURE ShowInfShipper(your_order_id INT(10))
	BEGIN
		SELECT first_name, last_name, tel, company FROM shippers K INNER JOIN orders G ON K.id = G.shipper_id WHERE your_order_id = G.id; 
	END//
 DELIMITER ;
CALL ShowInfShipper(1);










