USE shoppingretail;
-- create the view SaleAndProfitPerOrder
CREATE OR REPLACE VIEW SaleAndProfitPerOrder AS
  SELECT order_id, SUM(order_details.quantity*output_price) AS sale, SUM(order_details.quantity*output_price-order_details.quantity*input_price) AS profit, ordered_date, customer_id
  FROM order_details 
  INNER JOIN products ON order_details.product_id = products.id 
  INNER JOIN orders ON order_details.order_id = orders.id
  GROUP BY order_id
  ORDER BY profit DESC;
-- this view looks like 
SELECT * FROM SaleAndProfitPerOrder;
-- to know the profit gained in April
SELECT SUM(profit) FROM SaleAndProfitPerOrder WHERE MONTH(ordered_date) = 4;
-- this view is not updatable and will be recalled whenever it is needed

-- create the view InProgressOrders
CREATE OR REPLACE VIEW InProgressOrders AS
  SELECT orders.id, ordered_date, orders.status, CONCAT(shippers.first_name, ' ', shippers.last_name) AS `shipper's name`, shippers.tel AS `shipper's tel`, CONCAT(customers.first_name, ' ', customers.last_name) AS `customer's name`, customers.tel AS `customer's tel`
  FROM orders 
  INNER JOIN shippers ON orders.shipper_id = shippers.id
  INNER JOIN customers ON orders.customer_id = customers.id
  WHERE orders.status NOT LIKE 'received'
  ORDER BY ordered_date;
-- this view looks like
SELECT * FROM InProgressOrders;
-- this is an updatable view
