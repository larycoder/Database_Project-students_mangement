DROP FUNCTION IF EXISTS profitByPercent;
DELIMITER //
CREATE FUNCTION profitByPercent (sale DECIMAL, profit DECIMAL) 
RETURNS DECIMAL
DETERMINISTIC
BEGIN 
  DECLARE profitPercent decimal;
  SET profitPercent = (profit)*100/(sale - profit); 
  RETURN profitPercent;
END //
DELIMITER ;

-- to find the total profit by percent 
select order_id, sale, profitByPercent(sale, profit) AS profitByPercent, ordered_date, customer_id FROM SaleAndProfitPerOrder;
