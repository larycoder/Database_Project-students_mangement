USE shoppingretail;
-- RETAILER REQUIREMENTS
-- 1. See the input_orders in a specific day
DROP PROCEDURE IF EXISTS SeeInputOrderInASpecificDay;
DELIMITER //
  CREATE PROCEDURE SeeInputOrderInASpecificDay(IN search_day DATETIME)
    BEGIN 
      SELECT * FROM input_orders WHERE DOI = search_day;
    END //
  DELIMITER ;
CALL SeeInputOrderInASpecificDay('2019-04-02');

-- 2. See the input_orders imported in a month
DROP PROCEDURE IF EXISTS SeeInputOrderInMonth;
DELIMITER //
  CREATE PROCEDURE SeeInputOrderInMonth(IN search_month INT(2))
    BEGIN 
      SELECT * FROM input_orders WHERE MONTH(DOI) =search_month;
    END //
  DELIMITER ;
CALL SeeInputOrderInMonth(4);

-- 3. Know a product is supplied in which input orders
DROP PROCEDURE IF EXISTS SeeInputOrderOfProduct;
DELIMITER //
  CREATE PROCEDURE SeeInputOrderOfProduct(IN product_name VARCHAR(45))
    BEGIN 
      SELECT A.id FROM input_orders A INNER JOIN products B ON A.product_id = B.id WHERE B.name = product_name;
    END //
  DELIMITER ;
CALL SeeInputOrderOfProduct('Sweater');

-- 4. See product information
DROP PROCEDURE IF EXISTS ProductInfo;
DELIMITER //
  CREATE PROCEDURE ProductInfo()
    BEGIN 
      SELECT A.id product_id, name, author, genre, status, input_price, output_price FROM products A INNER JOIN books B ON A.id = B.product_id;
      SELECT C.id product_id, name, size, color, material, status, input_price, output_price FROM products C INNER JOIN clothes D ON C.id = D.product_id;
    END //
  DELIMITER ;
CALL ProductInfo();

-- 5. See the orders made in a specific day
DROP PROCEDURE IF EXISTS SeeOrdersInDay ;
DELIMITER //
  CREATE PROCEDURE SeeOrdersInDay(IN day_order DATETIME)
    BEGIN 
      SELECT * FROM orders WHERE ordered_date = day_order;
    END //
  DELIMITER ;
CALL SeeOrdersInDay('2019-01-03');

-- See the orders made in a specific month
DROP PROCEDURE IF EXISTS SeeOrdersInMonth;
DELIMITER //
  CREATE PROCEDURE SeeInputOrderInMonth(IN search_month INT(2))
    BEGIN 
      SELECT * FROM orders WHERE MONTH(ordered_date) = search_month;
    END //
  DELIMITER ;
CALL SeeInputOrderInMonth(4);

-- 6. See a product is ordered in which orders
DROP PROCEDURE IF EXISTS FindOrdersAProductIN;
DELIMITER //
  CREATE PROCEDURE FindOrdersAProductIN(IN product_name VARCHAR(45))
    BEGIN 
      SELECT order_id FROM order_details INNER JOIN products ON products.id = order_details.product_id WHERE products.name = product_name;
    END //
  DELIMITER ;
CALL FindOrdersAProductIN('The outsider');

-- 7. Know the shipper information of an order
DROP PROCEDURE IF EXISTS ShipperInfoOfAnOrder;
DELIMITER //
  CREATE PROCEDURE ShipperInfoOfAnOrder(IN order_id INT(10))
    BEGIN 
      SELECT B.id shipper_id, CONCAT(B.first_name, ' ',B.last_name) AS shipper_name, B.tel, B.company from orders A INNER JOIN shippers B ON A.shipper_id = B.id WHERE A.id = order_id;
    END //
  DELIMITER ;
CALL ShipperInfoOfAnOrder(2);

-- 8. Know the status of the order
DROP PROCEDURE IF EXISTS StatusOfAnOrder;
DELIMITER //
  CREATE PROCEDURE StatusOfAnOrder(IN order_id INT(10))
    BEGIN 
      SELECT status FROM orders WHERE orders.id = order_id;
    END //
  DELIMITER ;
CALL StatusOfAnOrder(2);

