USE shoppingretail;
-- Table products'dat 
INSERT INTO `products` (`id`, `name`, `quantity`, `status`, `input_price`, `output_price`) VALUES (1, "Short Sleeve Graphic Pocket T-Shirt", 10, 1, 100000, 200000);
INSERT INTO `products` (`id`, `name`, `quantity`, `status`, `input_price`, `output_price`) VALUES (2, 'The outsider', 10 , 1, 200000, 340000);
INSERT INTO `products` (`id`, `name`, `quantity`, `status`, `input_price`, `output_price`) VALUES (3, "Unisex Casual 3D T-Shirt Short Sleeve", 30, 1, 200000, 400000);
INSERT INTO `products` (`id`, `name`, `quantity`, `status`, `input_price`, `output_price`) VALUES (4, 'denim-skirt', 40, 1, 210000, 360000);
INSERT INTO `products` (`id`, `name`, `quantity`, `status`, `input_price`, `output_price`) VALUES (5, 'pencil-skirt', 40, 1, 300000, 500000);
INSERT INTO `products` (`id`, `name`, `quantity`, `status`, `input_price`, `output_price`) VALUES (6, 'Still Me', 15, 1, 150000, 220000);
INSERT INTO `products` (`id`, `name`, `quantity`, `status`, `input_price`, `output_price`) VALUES (7, 'Circle', 10, 1, 100000, 240000);
INSERT INTO `products` (`id`, `name`, `quantity`, `status`, `input_price`, `output_price`) VALUES (8, 'sweater', 50, 1, 300000, 450000);
INSERT INTO `products` (`id`, `name`, `quantity`, `status`, `input_price`, `output_price`) VALUES (9, 'The Great Alone', 20, 1, 150000, 280000);
INSERT INTO `products` (`id`, `name`, `quantity`, `status`, `input_price`, `output_price`) VALUES (10, 'Vengeful', 10, 1, 200000, 320000);

-- Table books' data
INSERT INTO `books` (`product_id`, `genre`, `author`) VALUES (2, 'Thriller', 'Stephen King');
INSERT INTO `books` (`product_id`, `genre`, `author`) VALUES (6, 'Fiction', 'Jojo Moyes');
INSERT INTO `books` (`product_id`, `genre`, `author`) VALUES (7, 'Fantasy', 'Madeline Miller');
INSERT INTO `books` (`product_id`, `genre`, `author`) VALUES (9, 'Historical Fiction', 'Kristin Hannah');
INSERT INTO `books` (`product_id`, `genre`, `author`) VALUES (10, 'Science Fiction', 'V.E. Schwab');

-- Table clothes' data
INSERT INTO `clothes` (`product_id`, `size`, `color`, `material`) VALUES (1, 'M', 'green', 'Cotton');
INSERT INTO `clothes` (`product_id`, `size`, `color`, `material`) VALUES (3, '28', 'blue', 'Cotton' );
INSERT INTO `clothes` (`product_id`, `size`, `color`, `material`) VALUES (4, 'M', 'blue', 'Denim' );
INSERT INTO `clothes` (`product_id`, `size`, `color`, `material`) VALUES (5, 'M', 'black', 'Vicose' );
INSERT INTO `clothes` (`product_id`, `size`, `color`, `material`) VALUES (8,'L', 'navy', 'Acrylic' );

-- Table customers'data
INSERT INTO `customers` (`id`, `first_name`, `last_name`, `address`, `city`, `country`, `email`, `tel`) VALUES (1, 'Thanh Van', 'Nguyen', '1 Hoang Quoc Viet, Cau Giay, Ha Noi', 'Ha Noi', 'Viet Nam', 'thanhvan@gmail.com', '0911111234');
INSERT INTO `customers` (`id`, `first_name`, `last_name`, `address`, `city`, `country`, `email`, `tel`) VALUES (2, 'Hoang Anh', 'Tran', '10 Ton Duc Thang, Dong Da, Ha Noi', 'Ha Noi', 'Viet Nam', 'hoanganh@gmail.com', '0911111235');
INSERT INTO `customers` (`id`, `first_name`, `last_name`, `address`, `city`, `country`, `email`, `tel`) VALUES (3, 'Thanh Lam ', 'Vu', '20 Tran Cung, Cau Giay, Ha Noi', 'Ha Noi', 'Viet Nam', 'thanhlam@gmail.com', '0936883523');
INSERT INTO `customers` (`id`, `first_name`, `last_name`, `address`, `city`, `country`, `email`, `tel`) VALUES (4, 'Van Nam', 'Doan', '37 Kham Thien, Doang Da, Ha Noi', 'Ha Noi', 'Viet Nam', 'vannam@gmail.com', '0913537186');
INSERT INTO `customers` (`id`, `first_name`, `last_name`, `address`, `city`, `country`, `email`, `tel`) VALUES (5, 'Minh Quang', 'Do', '70 Hoang Quoc Viet, Cau Giay, Ha Noi', 'Ha Noi', 'Viet Nam', 'minhquang@gmail.com', '0917311234');

-- Table shippers' data
INSERT INTO `shippers` (`id`, `first_name`, `last_name`, `tel`, `company`) VALUES (1, 'Van Anh', 'Nguyen', '0121435256', 'Company A');
INSERT INTO `shippers` (`id`, `first_name`, `last_name`, `tel`, `company`) VALUES (2, 'Phan Anh', 'Nguyen', '0926629469', 'Company A');
INSERT INTO `shippers` (`id`, `first_name`, `last_name`, `tel`, `company`) VALUES (3, 'Anh Minh', 'Ta', '0127472057', 'Company B');
INSERT INTO `shippers` (`id`, `first_name`, `last_name`, `tel`, `company`) VALUES (4, 'Quang Anh', 'Tran', '0916420774', 'Company C');
INSERT INTO `shippers` (`id`, `first_name`, `last_name`, `tel`, `company`) VALUES (5, 'Van Khiem', 'Nguyen', '0125984913', 'Company D');

-- Table producers' data
INSERT INTO `producers` (`id`, `name`, `address`, `city`, `country`, `email`, `tel`) VALUES (1, 'NXB Giao Duc', '81 Tran Hung Dao, Hoan Kiem, Ha Noi', 'Ha Noi', 'Viet Nam', 'nxbgiaoduc@gmail.com', '0243822080');
INSERT INTO `producers` (`id`, `name`, `address`, `city`, `country`, `email`, `tel`) VALUES (2, 'NXB Dai hoc Su Pham', '3 Hoang Quoc Viet, Cau Giay, Ha noi', 'Ha Noi', 'Viet Nam', 'nxbdhsupham@gmail.com', '0247822801');
INSERT INTO `producers` (`id`, `name`, `address`, `city`, `country`, `email`, `tel`) VALUES (3, 'Canifa', '5 Cat Linh, Dong Da, Ha Noi', 'Ha Noi', 'Viet Nam', 'canifa@gmail.com', '0242982572');
INSERT INTO `producers` (`id`, `name`, `address`, `city`, `country`, `email`, `tel`) VALUES (4, 'Bo Sua By Boo', '45 Ba Trieu, Hoan Kiem, Ha Noi', 'Ha Noi', 'Viet Nam', 'bosuabyboo@gmail.com', '0246264924');
INSERT INTO `producers` (`id`, `name`, `address`, `city`, `country`, `email`, `tel`) VALUES (5, 'IVY Moda', '391 Hoang Quoc Viet, Cau Giay, Ha Noi', 'Ha Noi', 'Viet Nam', 'ivymoda@gmail.com', '0247902802');

-- Table input_orders'data
INSERT INTO `input_orders` (`id`, `quantity`, `DOM`, `DOI`, `product_id`, `producer_id`) VALUES (1, 20, '2018-12-13', '2019-01-01', 1, 4);
INSERT INTO `input_orders` (`id`, `quantity`, `DOM`, `DOI`, `product_id`, `producer_id`) VALUES (2, 30, '2018-12-24', '2019-01-05', 2, 1);
INSERT INTO `input_orders` (`id`, `quantity`, `DOM`, `DOI`, `product_id`, `producer_id`) VALUES (3, 25, '2019-03-14', '2019-03-15', 3, 3);
INSERT INTO `input_orders` (`id`, `quantity`, `DOM`, `DOI`, `product_id`, `producer_id`) VALUES (4, 35, '2019-03-30', '2019-04-02', 4, 4);
INSERT INTO `input_orders` (`id`, `quantity`, `DOM`, `DOI`, `product_id`, `producer_id`) VALUES (5, 30, '2019-03-30', '2019-04-02', 5, 5);
INSERT INTO `input_orders` (`id`, `quantity`, `DOM`, `DOI`, `product_id`, `producer_id`) VALUES (6, 20, '2019-04-05', '2019-04-07', 6, 1);
INSERT INTO `input_orders` (`id`, `quantity`, `DOM`, `DOI`, `product_id`, `producer_id`) VALUES (7, 40, '2019-04-10', '2019-04-15', 7, 2);
INSERT INTO `input_orders` (`id`, `quantity`, `DOM`, `DOI`, `product_id`, `producer_id`) VALUES (8, 30, '2019-04-20', '2019-04-21', 8, 4);
INSERT INTO `input_orders` (`id`, `quantity`, `DOM`, `DOI`, `product_id`, `producer_id`) VALUES (9, 20, '2019-04-20', '2019-04-21', 9, 2);
INSERT INTO `input_orders` (`id`, `quantity`, `DOM`, `DOI`, `product_id`, `producer_id`) VALUES (10, 40, '2019-04-30', '2019-05-01', 10, 2);

-- Table orders' data
INSERT INTO `orders` (`id`, `ordered_date`, `received_date`, `ship_price`, `status`, `customer_id`, `shipper_id`) VALUES (1, '2019-01-03', NULL, 20000, 'preparing', 1, 1);
INSERT INTO `orders` (`id`, `ordered_date`, `received_date`, `ship_price`, `status`, `customer_id`, `shipper_id`) VALUES (2, '2019-04-05', '2019-04-10', 30000, 'received', 1, 2);
INSERT INTO `orders` (`id`, `ordered_date`, `received_date`, `ship_price`, `status`, `customer_id`, `shipper_id`) VALUES (3, '2019-04-07', NULL, 20000, 'shipping', 2, 2);
INSERT INTO `orders` (`id`, `ordered_date`, `received_date`, `ship_price`, `status`, `customer_id`, `shipper_id`) VALUES (4, '2019-05-05', '2019-05-10', 30000, 'received', 3, 4);
INSERT INTO `orders` (`id`, `ordered_date`, `received_date`, `ship_price`, `status`, `customer_id`, `shipper_id`) VALUES (5, '2019-05-20', '2019-06-01', 20000, 'received', 4, 5);

-- Table order_details
INSERT INTO `order_details` (`id`, `quantity`, `product_id`, `order_id`) VALUES (1, 2, 1, 1);
INSERT INTO `order_details` (`id`, `quantity`, `product_id`, `order_id`) VALUES (2, 1, 2, 2);
INSERT INTO `order_details` (`id`, `quantity`, `product_id`, `order_id`) VALUES (3, 3, 3, 1);
INSERT INTO `order_details` (`id`, `quantity`, `product_id`, `order_id`) VALUES (4, 1, 4, 2);
INSERT INTO `order_details` (`id`, `quantity`, `product_id`, `order_id`) VALUES (5, 2, 1, 3);
INSERT INTO `order_details` (`id`, `quantity`, `product_id`, `order_id`) VALUES (6, 1, 5, 4);
INSERT INTO `order_details` (`id`, `quantity`, `product_id`, `order_id`) VALUES (7, 4, 6, 5);
INSERT INTO `order_details` (`id`, `quantity`, `product_id`, `order_id`) VALUES (8, 3, 7, 1);
INSERT INTO `order_details` (`id`, `quantity`, `product_id`, `order_id`) VALUES (9, 1, 8, 3);
INSERT INTO `order_details` (`id`, `quantity`, `product_id`, `order_id`) VALUES (10, 2, 10, 5);


